@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <passport-personal-access-tokens></passport-personal-access-tokens>
    </div>
</div>
@endsection
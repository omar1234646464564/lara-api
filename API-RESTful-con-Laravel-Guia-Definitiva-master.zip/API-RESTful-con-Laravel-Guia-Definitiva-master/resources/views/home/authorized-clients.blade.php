@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <passport-authorized-clients></passport-authorized-clients>
    </div>
</div>
@endsection